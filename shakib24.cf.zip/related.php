<?php
include 'includes/info.php';
echo '<h2 align="left" class="header-title"><i class="fa fa-th-list"></i>Related videos</h2>';
echo ''.$yllix.'';
$grab=ngegrab('https://www.googleapis.com/youtube/v3/search?key='.$devkey.'&part=snippet&maxResults=20&relatedToVideoId='.$_GET['id'].'&type=video');
$json = json_decode($grab);
if($json)
{
foreach($json->items as $hasil) 
{
$name = $hasil->snippet->title;
$link = $hasil->id->videoId;
$tgl = $hasil->snippet->publishedAt;
$date = dateyt($tgl);
$des = $hasil->snippet->description;
$chid = $hasil->snippet->channelId;
$linkmake = preg_replace("/[^A-Za-z0-9[:space:]]/","$1",$name);
$linkmake = str_replace(' ','-',$linkmake);
$final = strtolower("$linkmake");
echo '<ul id="listing" class="arrow-bullet-listing">
<li><table cellspacing="7"><tr></tbody><td class="tblimg"><img src="http://ytimg.googleusercontent.com/vi/'.$link.'/mqdefault.jpg" alt="'.$name.'" height="80px" width="140px"/></td> <td colspan="1"><a href="/video-download/'.$link.'/'.$final.'.html"><span class="song-name"><b> '.$name.'</b></span></a>
<br style="clear:both;"></td></tbody> </tr></table></li></ul></br></div>';
}
}
?>