<?php
include 'includes/func.php';

/*
THANKS To Shakib Ahmed
.................................................................................

Search ShakibAXE On FACEBOOK 

...............................................................................


If you face any problem you may contact with me. 
http://fb.com/ShakibAXE

*/

$title  = 'Shakib24.Cf - Youtube Downloader'; //Edit Homepage Title


include 'includes/config.php';
echo'
<section class="white-block"><!-- WHITE BLOCK -->
  <h2 align="left" class="header-title">Trading Videos</h2>';
if($_GET['q']){
$q = $_GET['q'];
} else {
$a = array(" ");
$b = count($a)-1;
$q = $a[rand(0,$b)];
}
$qu=$q;
$qu=str_replace(" ","+", $qu);
$qu=str_replace("-","+", $qu);
$qu=str_replace("_","+", $qu);
if(strlen($_GET['page']) >1){$yesPage=$_GET['page'];}
else{$yesPage='';}
$grab=ngegrab('https://www.googleapis.com/youtube/v3/search?key='.$devkey.'&part=snippet&order=relevance&maxResults=100&q='.$qu.'&pageToken='.$yesPage.'&type=video');
$json = json_decode($grab);
$nextpage=$json->nextPageToken;
$prevpage=$json->prevPageToken;
if($json)
{
foreach ($json->items as $sam)
{
$link= $sam->id->videoId;
$name= $sam->snippet->title;
$desc = $sam->snippet->description;
$chtitle = $sam->snippet->channelTitle;
$chid = $sam->snippet->channelId;
$date = dateyt($sam->snippet->publishedAt);
$sam = ngegrab('https://www.googleapis.com/youtube/v3/videos?key='.$devkey.'&part=contentDetails,statistics&id='.$link.'');
$linkmake = preg_replace("/[^A-Za-z0-9[:space:]]/","$1",$name);
$linkmake = str_replace(' ','-',$linkmake);
$final = strtolower("$linkmake");
$dt=json_decode($sam);
foreach ($dt->items as $dta){
$time=$dta->contentDetails->duration;
$duration= format_time($time);
$views= $dta->statistics->viewCount;   
}
echo '<ul id="listing" class="arrow-bullet-listing">
<li><table cellspacing="7"><tr></tbody><td class="tblimg"><img src="http://ytimg.googleusercontent.com/vi/'.$link.'/mqdefault.jpg" alt="'.$name.'" height="80px" width="140px"/></td> <td colspan="1"><a href="/video-download/'.$link.'/'.$final.'.html"><span class="song-name"><b> '.$name.'</b></span></a><br/>
<a href="#" class="artist"><span class="yellow-color"><i class="fa fa-user-circle-o"></i> '.$chtitle.'</span></a><br/>
<span class="yellow-color"><i class="fa fa-clock-o"></i> '.$duration.' </span>


<br style="clear:both;"></td></tbody> </tr></table></li></ul>
';
}
include'includes/ucweb.php';
echo '</div>';
}



include 'category.php';
include 'includes/foot.php';
?>