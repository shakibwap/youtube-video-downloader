<section class="white-block"><!-- WHITE BLOCK -->
<h2 align="center" class="header-title">Categories</h2>


<ul class="arrow-bullet-listing"><a href="/category/Hindi-Dubbed-Full-Movie"> <li><div class="song-highlights"><span class="song-name">Hindi Dubbed Movies</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/Bollywood-Movie-Song"> <li><div class="song-highlights"><span class="song-name">Hindi Video Songs</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/Goldmines-Telefilms"> <li><div class="song-highlights"><span class="song-name">Goldmines Movies</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/Hindi-Romantic-Song"> <li><div class="song-highlights"><span class="song-name">Hindi Romantic Songs</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/T-Series"> <li><div class="song-highlights"><span class="song-name">T-Series Songs Download</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/Zee-Music-Company"> <li><div class="song-highlights"><span class="song-name">Zee Music Company</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/New-Bangla-Movie"> <li><div class="song-highlights"><span class="song-name">Bangla Movie Download</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/Arijit-Singh-Song"> <li><div class="song-highlights"><span class="song-name">Arijit Singh All Songs</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/Atif-Aslam-Song"> <li><div class="song-highlights"><span class="song-name">Atif Aslam Songs Download</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/CD-Choice"> <li><div class="song-highlights"><span class="song-name">CD Choice Bangla Songs</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/Bangla-Old-Sad-Song"> <li><div class="song-highlights"><span class="song-name">Bangla Old Sad Songs</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/Guru-Randhawa-Song"> <li><div class="song-highlights"><span class="song-name">Guru Randhawa Songs</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/2018-Bangla-Song-Video"> <li><div class="song-highlights"><span class="song-name">Bangla New Songs</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/New-Punjabi-Song"> <li><div class="song-highlights"><span class="song-name">Punjabi New Songs</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/Tamil-Full-Movie"> <li><div class="song-highlights"><span class="song-name">Tamil Action Movies</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/Bangla-new-Natok"> <li><div class="song-highlights"><span class="song-name">Bangla Natok</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/Kolkata-Movie-song"> <li><div class="song-highlights"><span class="song-name">Kolkata Movie Songs</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/2020-new-hindi-song"> <li><div class="song-highlights"><span class="song-name">2020 Hindi Songs Video</span></div></li></a></ul> 

<ul class="arrow-bullet-listing"><a href="/category/Hot-Uncut-Movie-Scenes"> <li><div class="song-highlights"><span class="song-name">Movie Hot Scenes</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/Telugu-Full-Movie"> <li><div class="song-highlights"><span class="song-name">Telugu Full Movie</span></div></li></a></ul>


<ul class="arrow-bullet-listing"><a href="/category/Islamic-Video"> <li><div class="song-highlights"><span class="song-name">Islamic Videos</span></div></li></a></ul>


<ul class="arrow-bullet-listing"><a href="/category/2018-Indian-Tv-Serial"> <li><div class="song-highlights"><span class="song-name">Indian TV Serial</span></div></li></a></ul>


<ul class="arrow-bullet-listing"><a href="/category/Sony-AATH"> <li><div class="song-highlights"><span class="song-name">Sony AATH Video Download</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/Gopal-Bhar"> <li><div class="song-highlights"><span class="song-name">Gopal Bhar Download</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/TV-Show"> <li><div class="song-highlights"><span class="song-name">TV Show Download</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/Love-Romantic-Song"> <li><div class="song-highlights"><span class="song-name">Love Songs</span></div></li></a></ul>

<ul class="arrow-bullet-listing"><a href="/category/2020-wwe-raw"> <li><div class="song-highlights"><span class="song-name">WWE Raw 2020 Videos</span></div></li></a></ul>

  </section><!-- /WHITE BLOCK -->