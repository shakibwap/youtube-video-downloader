<?php
include 'includes/func.php';
include 'includes/info.php';
$yf=ngegrab('https://www.googleapis.com/youtube/v3/videos?key='.$devkey.'&part=snippet,contentDetails,statistics,topicDetails&id='.$_GET['id'].'');
$yf=json_decode($yf);

$mdlink=str_replace('==== Load player script and execute patterns ====

Loading player ID = vflAAoWvh

==== Player script was not found for id: vflAAoWvh ====',$mdlink); // Span Class Replaceing


if($yf){
foreach ($yf->items as $item)
{

$name=$item->snippet->title;
$des = $item->snippet->description;
$date = dateyt($item->snippet->publishedAt);
$channelId = $item->snippet->channelId;
$chtitle = $item->snippet->channelTitle;
$ctd=$item->contentDetails;
$duration=format_time($ctd->duration);
$hd = $ctd->definition;
$st= $item->statistics;
$views = $st->viewCount;
$likes = $st->likeCount;
$dislike = $st->dislikeCount;
$favoriteCount = $st->favoriteCount;
$commentCount = $st->commentCount;
{$title='Download '.$name.' ('.$duration.') in Mp3, 3GP, MP4, FLV and WEBM Format';}
$tag=$name;
$tag=str_replace(" ",",", $tag);
$dtag=$des;
include 'includes/config.php';
echo '<h2 class="header-title" align="center">'.$name.'</h2>';
echo '<div class="group" align="left">';

echo '<div class="vdo_bg" id="'.$_GET['id'].'">';
echo '<iframe src="https://www.youtube.com/embed/'.$_GET['id'].'?border=1&autohide=1&disablekb=1&egm=1&fs=1&iv_load_policy=3&loop=1&rel=0&showinfo=0&showsearch=0&theme=light" allowfullscreen="yes" width="100%" height="200" frameborder="0"></iframe>';
echo '<br/>';
echo '<img src="http://ytimg.googleusercontent.com/vi/'.$_GET['id'].'/1.jpg"/><img src="http://ytimg.googleusercontent.com/vi/'.$_GET['id'].'/2.jpg"/><img src="http://ytimg.googleusercontent.com/vi/'.$_GET['id'].'/3.jpg"/>';
echo ''.$adb.'</div>
<p class="pagination"><a class="active" href="http://img.youtube.com/vi/'.$_GET['id'].'/hqdefault.jpg"><span aria-hidden="true">Thumbnail (HQ)</span></a> <a class="active" href="http://img.youtube.com/vi/'.$_GET['id'].'/default.jpg"><span aria-hidden="true">Thambnail (Medium)</span></a></p><div class="blue-bg-section">
<a href="https://shakibwap.cu.ma/watch?v='.$_GET['id'].'" class="active">Download Now [Server 1]</a></div>
<br/><div class="blue-bg-section">
<a href="http://wapmash.ml/yt/es.php?id='.$_GET['id'].'" class="active">Download Now [Server 2]</a></div>
<hr/>
';
echo '<section class="film-summary">';
echo '<table>';
echo '<tr valign="top">';
echo '<td width="30%"><span class="yellow-color bold">Cloud Tags</span></td>';
echo '<td>:</td>';
echo '<td>'.$tag.'</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%"><span class="yellow-color bold">Source Link</span></td>';
echo '<td>:</td>';
echo '<td>https://www.youtube.com/watch?v='.$_GET['id'].'</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%"><span class="yellow-color bold">Defination</span></td>';
echo '<td>:</td>';
echo '<td> '.$hd.'</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%"><span class="yellow-color bold">Channel</span></td>';
echo '<td>:</td>';
echo '<td>'.$chtitle.'</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%"><span class="yellow-color bold">Comments</span></td>';
echo '<td>:</td>';
echo '<td>'.$commentCount.'</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%"><span class="yellow-color bold">Views</span></td>';
echo '<td>:</td>';
echo '<td>'.$views.'</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%"><span class="yellow-color bold">Likes</span></td>';
echo '<td>:</td>';
echo '<td>'.$likes.'</td>';
echo '</tr>';
echo '<tr valign="top">';
echo '<td width="30%"><span class="yellow-color bold">Dislikes</span></td>';
echo '<td>:</td>';
echo '<td>'.$dislike.'</td>';
echo '<tr valign="top">';
echo '<td width="30%"><span class="yellow-color bold">Duration</span></td>';
echo '<td>:</td>';
echo '<td>'.$duration.'</td>';
echo '</tr>';
echo '</table>';
echo '</section>';
echo '
  <section class="song-lyrics">
   <strong>Tags: </strong><small> '.$name.' download full video
'.$name.'  ,  '.$chtitle.' latest videos, official, download Video, full movie download, songs, mp3, full video download, 3gp video download, '.$name.' Mp3 Audio download, convert to download, mp3 download free, torrent download, '.$chtitle.' all video download, '.$chtitle.' all mp3 download, '.$chtitle.' official channel, '.$chtitle.' new upload videos, new songs, released, download free, T-Series all latest videos, prank videos, hindi dubbed, album all songs download, watch online, hd print download, 2018 movies, movie download, uncut hot scenes, malayam movies, into hindi dubbed download, 720p, 1280p download hd, convert format mp3, mp4 format, flv, download hd google, full movie, new songs</small></section>
<div class="group" align="left"></div>
';

}
}
include'includes/ucweb.php';
include 'related.php';
include 'includes/foot.php';
?>