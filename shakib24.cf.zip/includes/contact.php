<?php
include 'config.php'; ?>

  <h2 align="left" class="header-title">Contact Us Directly.</h2>
   <section class="song-lyrics">
   <strong><font color="red">Read the thoughts Shakib24.Cf wanna share to you..</font><p/>

We Recommend sending as an email directly through our E-mail address if it is an for important matter. Send an email and We will reply as soon as possible. Regarding to your message matter, thanks.
<h3>Send Mail Via: <script type="text/javascript">
	atOptions = {
		'key' : 'c57c30edc61c8875c2b607b0aee3eaf3',
		'format' : 'iframe',
		'height' : 250,
		'width' : 300,
		'params' : {}
	};
	document.write('<scr' + 'ipt type="text/javascript" src="http' + (location.protocol === 'https:' ? 's' : '') + '://www.bestdisplaycontent.com/c57c30edc61c8875c2b607b0aee3eaf3/invoke.js"></scr' + 'ipt>');
</script> <font color="green">shakibwap75@gmail.com <br>shakib320official@gmail.com <br>zorexnisho@yahoo.com</font></h3></section>
<?php
include 'foot.php'; ?>
