<?php include'adsense.php';?>
<?php
include 'includes/info.php';
?>
<script>

jQuery(document).ready(function() {
$.fn.googleSuggest = function(opts){
  opts = $.extend({service: 'youtube', secure: false}, opts);

  var services = {
    youtube: { client: 'youtube', ds: 'yt' },
    books: { client: 'books', ds: 'bo' },
    products: { client: 'products-cc', ds: 'sh' },
    news: { client: 'news-cc', ds: 'n' },
    images: { client: 'img', ds: 'i' },
    web: { client: 'psy', ds: '' },
    recipes: { client: 'psy', ds: 'r' }
  }, service = services[opts.service];

  opts.source = function(request, response){
    $.ajax({
      url: 'http'+(opts.secure?'s':'')+'://clients1.google.com/complete/search',
      dataType: 'jsonp',
      data: {
        q: request.term,
        nolabels: 't',
        client: service.client,
        ds: service.ds
      },
      success: function(data) {
        response($.map(data[1], function(item){
          return { value: $("<span>").html(item[0]).text() };
        }));
      }
    });  
  };

    opts.select = function(event,ui){
      $("#inputs").val(ui.item.label);
      $("#form").submit();
      
      };
  
  return this.each(function(){
    $(this).autocomplete(opts);
  });
}

$('#inputs').googleSuggest();

});

</script>

<table style="width:100%"> <tr> <th><!-- Footer Start --><footer id="footer">
 <font color=""> &copy; 2021 All rights are reserved by Shakib24.Cf</font>
</footer><br/></th> </tr>
<center><script type="text/javascript" src="//widget.supercounters.com/ssl/online_i.js"></script><script type="text/javascript">sc_online_i(1595604,"FFFFFF","000000");</script></center>
<shakibahmed style="display:none;">
</body>                            
</html>