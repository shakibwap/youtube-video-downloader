<?php
include 'info.php';
?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<head>
<meta http-equiv="content-type" content="application/xhtml xml; charset=utf-8"/>
<meta name="google-site-verification" content="<?php echo $google;?>"/>
<title><?php echo $title;?></title> 
<meta name="description" content="<?php echo $desc;?>"/>
<meta name="keywords" content="<?php echo $key;?>"/>
<meta property="og:title" content="<?php echo $title;?>"/>
<meta property="og:description" content="Download in Hd, Mp4, Webm, 3gp and in Mp3"/>
<meta property="og:url" content="http://<?php echo ''.$host.'';?>/"/>
<meta property="og:site_name" content="Shakib24.Cf"/>
<meta property="og:image" content="http://i.ytimg.com/vi/'.$_GET['id'].'/default.jpg"/>
<meta property="og:type" content="video"/>
<meta property="og:video:width" content="640"/>
<meta property="og:video:height" content="360"/>
<meta name="robots" content="index,follow"/>
<meta name="googlebot" content="index,follow"/>
<meta name="spiders" content="all"/>
<meta name="msnbot" content="index,follow"/>
<meta name="language" content="en"/>
<meta name="author" content="Shakib Ahmed">
<meta name="revisit-after" content="5 hours"/>
<meta http-equiv="content-type" content="application/xhtml xml; charset=utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="cache-control" content="max-age=0" />
<meta http-equiv="content-language" content="en"/>
<meta name="twitter:site" content="@ShakibAXE"/>
<meta name="twitter:creator" content="@ShakibAXE"/>
<meta name="twitter:domain" content="Shakib24.Cf"/>
<meta name="twitter:title" content="<?php echo $title;?>">
<meta name="twitter:description" content="Download in Hd, Mp4, Webm and in 3gp">
<meta content="follow, all" name="robots" />
<meta content="follow, all" name="seznambot" />
<meta content="follow, all" name="Slurp" />
<meta content="follow, all" name="ia_archiver" />
<meta content="follow, all" name="Baiduspider"/>
<meta content="follow, all" name="BecomeBot"/>
<meta content="follow, all" name="Bingbot"/>
<meta content="follow, all" name="btbot"/>
<meta content="follow, all" name="Dotbot"/>
<meta content="follow, all" name="Yeti"/>
<meta content="follow, all" name="Teoma"/>
<meta content="follow, all" name="Yandex"/>
<meta content="follow, all" name="FAST-WebCrawler"/>
<meta content="follow, all" name="FindLinks" />
<meta content="follow, all" name="FyberSpider" />
<meta content="follow, all" name="008" />
<meta name="generator" content="itube" />
<meta name="distribution" content="global"/>
<meta content="10" name="Pagerank"/>
<meta content="never" name="Expires"/>
<meta content="all" name="Audience"/>

 <!--KM core CSS -->
    <link rel="stylesheet" type="text/css" media="screen" href="/css/main.css"/>
    <link rel="stylesheet" type="text/css" media="screen" href="/css/mobile.css"/>
    <link rel="stylesheet" type="text/css" media="screen" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
    <link rel="icon" href="https://shakibwap.000webhostapp.com/favicon.png" type="image/x-icon"/>
    <link href="https://fonts.googleapis.com/css?family=Josefin Sans:400,700" rel="stylesheet" type="text/css">
      <script type="text/javascript" src="/css/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="/css/custom.js"></script>


</head>
<body>
   <div class="headerlogotop">
<i class="fas fa-video"></i><a href="/">Shakib24.Cf</a>
</div><div class="clear"></div>
<div class="top-search clear">
<form action="/search.php" id="autoform" method="get">
<p align="center" style="background: #0072BC; height: 40px;">
<input type=""text" placeholder="Search keyword" name="q" id="searchText" class="text-fi" placeholder="" style="width: 40%; float: center; margin-top: 5px; width: 55%;"/>
<input type="submit" value="Search" class="top-search-btn-submit top-search-btn" style="margin-top: 5px; float: center; width: 22%">
</input>
</p>
</form>
</div>
<div class="clear"></div>
<?php
include '1adsense.php';
?>