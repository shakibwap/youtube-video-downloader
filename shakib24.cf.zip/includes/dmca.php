<?php
include 'config.php'; ?>

<h2 align="left" class="header-title">Digital Millennium Copyright Act (DMCA)</h2>
   <section class="song-lyrics">
   <strong>DMCA Policy: </strong>Please refer our Disclaimer here. If you think there is any problem with the video and you want to remove the video please report to Youtube. We do not host any content in our website. Everything is served by Youtube and data provide via Youtube API v3. We only provide the search results derived from the Youtube API v3 But we respect you concerns and if you want your videos to be removed from our website search result listing please use contact form to send us message. You may also send the email to shakibwap75@gmail.com for faster processing. After receiving the request, we will remove the search results as soon as possible.</section>
  
  <?php
include 'foot.php'; ?>